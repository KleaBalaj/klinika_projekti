<div id="footer" class="cf">
                    
                    <div class="column three">
                        <strong>Kontakt</strong>
                        <strong>Tel:</strong>+355696600666
                        <strong>Email:</strong>dentalcare@gmail.com
                    </div>
                        
                         <div class="column three">
                        <strong>Adresa</strong>
                         Rruga: "Grigor Durrsaku"
                          Durres, Albania
                    </div>
                        
                    <div class="column three last">
                        
                       <strong>Orari</strong>
                        <em>E hene-E premte</em><br>
                        09:00am-6:00pm<br><br>
                        
                        <em>E shtune</em><br>
                        10:00am-04:00pm<br><br>
                        
                        <em>E diele</em><br>
                        Mbyllur<br><br>
                        
                    </div>
                    
                    </div>
                
                    <small>&copy;<?php echo date('Y'); ?> <?php echo $emriKompanise; ?></small>
                   
                    </div>
            
                </div>
            
        <div clas="copyright-info">
       
            </div>

    </body>
</html>