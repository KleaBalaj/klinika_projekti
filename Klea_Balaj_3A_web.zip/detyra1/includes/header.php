<?php
$emriKompanise="Klinika DentalCare";

?>

<html>
<head>
    <title>DentalCare</title>
    <link href="/detyra1/style.css" rel="stylesheet">
    </head>
    <body >

        <div class="bllok">

                
         <img style="border: 4px solid black;
  padding:15px 160px 15px 160px;
  background: #0B4C5F;
  background-clip: border-box;  width:70%; height:65%; "src="img/banner1.jpg" alt="DentalCare">
                


            <div id="nav">
                <?php include('includes/nav.php'); ?>
            </div>

            <div class="content">
