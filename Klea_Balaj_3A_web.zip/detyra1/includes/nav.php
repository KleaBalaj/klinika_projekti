<ul>

<li><a href="index.php">Kreu</a></li>
 <li><a href="rreth.php">Rreth nesh</a></li>
     <li><a href="sh_kategori.php">Sherbime</a></li>
 <li><a href="stafi_db.php">Stafi</a></li>
    <li><a href="keshilla.php">Keshilla</a></li>
   <li><a href="login.php">Rezervo</a></li>
   <li><a href="kerkimi.php">Kerkimi</a></li>
 </ul>
