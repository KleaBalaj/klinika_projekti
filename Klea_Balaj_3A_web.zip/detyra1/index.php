<?php
define('TITLE', "Home| Klinika DentalCare");
include('includes/header.php');
?>
<div id="philosophy">
    <hr>
    <br>
    <br>
    <br>
    <br>
    <img src="/detyra/img/images.png" style="height:20%;width:25%;">
    <h1><strong>Klinika Dentare - DentalCare</strong></h1>
		<p>Ne kete klinike kryhen nje pjese e madhe e punimeve dentare ashtu dhe atyre kirurgjikale stomatologjike. Tek ne do te gjeni aparaturat,teknollogjine dhe metodat me bashkekohore te trajtimit. Cdo pacient eshte njesoj i rendesishem per ne dhe stafi yne eshte i perkushtuar te permbushe ne kohe dhe me cilesi cdo kerkese tuajen. Mirepresim cdo ankese dhe sugjerim lidhur me sherbimin tone.
 Tek DentalCare do te gjeni cilesine perkujdesjen dhe profesionalizmin qe gjithsecili nga ju meriton.
Stafi yne angazhohet t’ju ofroje asistencen dhe pas sherbimeve te kryera.Ne e garantojme punen tone dhe jemi te bindur qe nuk do t’ju zhgenjejme.

</p>
		<p>Misioni yne eshte te behemi klinika juaj e preferuar. </p>
    <br>
    <br>
    <br>
    <hr>

</div>

<?php
include('includes/footer.php');
?>
                