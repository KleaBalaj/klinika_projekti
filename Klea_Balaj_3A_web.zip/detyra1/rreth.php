<?php
	define("TITLE", "Rreth nesh | DentalCare");
	
	include('includes/header.php');
?>


<div>
     <img src="/detyra/img/rreth.png" style="border: 2px solid #006699;border-radius: 2px;width:40%; height:25%; float:left; margin-right:5%;margin-bottom:1%;">
    
    <h4>Kush jemi</h4>
    
Klinika jonë dentare është një qendër e specializuar në shërbimet dentare duke përfshirë fusha të ndryshme si implantologjia, kirurgjia orale, protetika, ortodoncia, paradontologjia, terapia konservative dhe estetike.<br>

Ne punojmë me një grup të madh mjekësh të specializuar që punojnë me entuziazëm, energji dhe profesionalizëm. Përveç kësaj, pacienteve tanë ne ju ofrojmë mbështetjen më të mirë nga i gjithë stafi, edukimin për higjienën orale, materialet me cilësinë më të lartë dhe garancinë për të gjitha nderhyrjet e kryera.<br>

Falë sallave të pajisura në mënyrë moderne, teknologjive të avancuara dhe metodave të sofistikuara u ofrojmë pacienteve tanë një shërbim të plotë dhe efektiv. Në sallat tona kirurgjikale ne kryejmë ndërhyrje implantologjike dhe kirurgjikale duke u siguruar pacientëve tanë kujdes dhe vëmendje profesionale, para dhe pas operacionit, sipas standardeve më të larta.<br>

Ne sigurohemi që pritja tek dentisti të jetë sa më e rehatshme duke e bërë çdo pacient të ndjehet komod. Ne jemi një klinikë dentare 50 metra larg nga qendra e qytetit. Me çmimet tona ekonomike, mund të kurseni  të paktën 60% dhe nderkohë mund edhe te pushoni.
<br>
<br>
<br>   
<hr>
    <img src="/detyra/img/reth3.jpg" style="border: 2px solid #006699;border-radius: 4px; width:45%; height:40%;float:left; margin-bottom:20px;">
     <img src="/detyra/img/rreth4.jpg" style="border: 2px solid #006699;border-radius: 4px; width:50%; height:40%;float:right;margin-bottom:20px;">
    
    <h4>Pajisjet dhe Teknologjia</h4>
 Pajisjet jane te markes gjermane Dentsply Sirona dhe italiane Anthos,nga shoqerite me te vjetra te prodhimit te poltroneve dentare.<br>
Jane pajisje me funksione te reja me fleksibilitet te larte te konfigurimeve, garanci te cilesise e besueshmeri te larte 
Funksionaliteti,performanca dhe teknologjia bashkohen ne nje besueshmeri te larte.<br>
Potenca e eres dixhitale ofron nje cilesi te punes me shume komoditet.<br>  
Integrim i plote i te gjithe sistemeve imazherike.
Siguria e sistemeve te higjenes ,konform te gjitha rregullave me te reja europiane.
    
    </div>
    <hr>
<?php
include('includes/footer.php');
?>